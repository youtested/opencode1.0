# Changelog

## 0.1.0

- Initial Acode IDE bridge for the local OpenCode server.
